//controller-usuario.js

// CRUD FUNCTIONS 
export const getUsuarios = (request, response) => {
    response.status(200).json("Respuesta satisfactoria");
}

export const getUsuariosId = (request, response) => {
    response.status(200).json("Respuesta satisfactoria");
}
